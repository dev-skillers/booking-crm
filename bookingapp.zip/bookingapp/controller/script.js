	// create the module and name it scotchApp
	var bookingApp = angular.module('bookingApp', ['ngRoute']);

	// configure our routes
	bookingApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'app/home.html',
				controller  : 'mainController'
			})
			
			// route for the login page
			.when('/login', {
				templateUrl : 'app/login.html',
				controller  : 'loginController'
			})
			
			// route for the signup page
			.when('/signup', {
				templateUrl : 'app/signup.html',
				controller  : 'signupController'
			})
			
			.when('/booking', {
				templateUrl : 'app/booking.html',
				controller  : 'bookingController'
			})

			// route for the about page
			.when('/about', {
				templateUrl : 'app/about.html',
				controller  : 'aboutController'
			})

			// route for the contact page
			.when('/contact', {
				templateUrl : 'app/contact.html',
				controller  : 'contactController'
			});
	});

	// create the controller and inject Angular's $scope
	bookingApp.controller('mainController', function($scope) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});
	
	bookingApp.controller('bookingController', function($scope) {
		// create a message to display in our view
		$scope.message = 'booking form comes here!';
	});
	
	
	bookingApp.controller('loginController', function($scope) {
		// create a message to display in our view
		$scope.message = '';
	});
	
	bookingApp.controller('signupController', function($scope) {
		// create a message to display in our view
		$scope.message = '';
	});


	bookingApp.controller('aboutController', function($scope) {
		$scope.message = 'Look! I am an about page.';
	});

	bookingApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us! JK. This is just a demo.';
	});